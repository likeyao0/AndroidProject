package com.example.novel;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.PatternMatcher;
import android.text.TextUtils;
import android.view.SurfaceHolder;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.novel.database.ShelfDbHelper;
import com.example.novel.entity.ShelfInfo;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class AddBooksActivity extends AppCompatActivity {

    private EditText et_book_title;
    private EditText et_book_author;
    private EditText et_book_details;
    private int et_book_img;
    private EditText et_book_contents;
    private SharedPreferences mSharedPreferences;
//    private SharedPreferences sharedPreferences;
//    private SharedPreferences.Editor editor;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_books);

//        sharedPreferences = getSharedPreferences("bid", MODE_PRIVATE);
//        editor = sharedPreferences.edit();
//        editor.putInt("bid", 1001);
//        editor.apply();

        et_book_title = findViewById(R.id.et_book_title);
        et_book_author = findViewById(R.id.et_book_author);
        et_book_details = findViewById(R.id.et_book_details);
        // et_book_img = findViewById(R.mipmap.lky031110);
        et_book_contents = findViewById(R.id.et_book_contents);

        mSharedPreferences = getSharedPreferences("user", MODE_PRIVATE);
        String username = mSharedPreferences.getString("username", null);

        findViewById(R.id.toolbar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        findViewById(R.id.btn_submit_book).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String newBookTitle = et_book_title.getText().toString();
                String newBookAuthor = et_book_author.getText().toString();
                String newBookDetails = et_book_details.getText().toString();
                String newBookContents = et_book_contents.getText().toString();
                if (TextUtils.isEmpty(newBookTitle) || TextUtils.isEmpty(newBookAuthor)) {
                    Toast.makeText(AddBooksActivity.this, "请完善信息~", Toast.LENGTH_SHORT).show();
                } else {
                    if (ShelfDbHelper.getInstance(AddBooksActivity.this).isExists(username,newBookTitle, newBookAuthor)) {
                        Toast.makeText(AddBooksActivity.this, "该书已经存在~", Toast.LENGTH_SHORT).show();
                    } else {
                        int randomIntInRange = 0;

                        List<ShelfInfo> shelfList = ShelfDbHelper.getInstance(AddBooksActivity.this).queryShelfList(username);
                        List<Integer> book_id = new ArrayList<>();
                        for (ShelfInfo item : shelfList){
                            book_id.add(item.getBook_id());
                        }
                        Random random = new Random();
                        int minValue = 1001;
                        int maxValue = 2001;
                        while (true){
                            randomIntInRange = random.nextInt(maxValue - minValue + 1) + minValue;
                            if (book_id.contains(randomIntInRange)){
                                continue;
                            } else {
                                break;
                            }
                        }
                        if (TextUtils.isEmpty(newBookDetails)){
                            Calendar calendar = Calendar.getInstance();
                            int year = calendar.get(Calendar.YEAR);
                            int month = calendar.get(Calendar.MONTH) + 1; // 注意月份是从0开始的
                            int day = calendar.get(Calendar.DAY_OF_MONTH);
                            int hour = calendar.get(Calendar.HOUR_OF_DAY);
                            int minute = calendar.get(Calendar.MINUTE);
                            int second = calendar.get(Calendar.SECOND);
                            newBookDetails = year + "/" + month + "/" + day +"\n" + hour + ":" + minute  + ":" + second;
                        }
                        if ( TextUtils.isEmpty(newBookContents)){
                            newBookContents = "null";
                        }
                        ShelfDbHelper.getInstance(AddBooksActivity.this).addShelf(username, randomIntInRange, 2131623938, newBookTitle, newBookAuthor, newBookDetails, newBookContents);
                        Toast.makeText(AddBooksActivity.this, "添加成功", Toast.LENGTH_SHORT).show();
                        setResult(1003);
                        finish();
                    }
                }
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    //    public void choosePhoto(View view) {
    //        if (ContextCompat.checkSelfPermission(this, Manifest.permission.DYNAMIC_RECEIVER_NOT_EXPORTED_PERMISSION));
    //    }
}