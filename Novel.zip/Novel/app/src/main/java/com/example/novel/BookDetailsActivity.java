package com.example.novel;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.example.novel.database.ShelfDbHelper;
import com.example.novel.entity.BookInfo;
import com.example.novel.model.UserInfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;

public class BookDetailsActivity extends AppCompatActivity {

    private ImageView book_img;
    private TextView book_title;
    private TextView book_author;
    private TextView book_details;
    private SharedPreferences mSharedPreferences;

    private BookInfo bookInfo;
//    private UserInfo userInfo;



    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_book_details);

//        userInfo = (UserInfo) getIntent().getSerializableExtra("userInfo");
        bookInfo = (BookInfo) getIntent().getSerializableExtra("bookInfo");
        mSharedPreferences = getSharedPreferences("user", MODE_PRIVATE);
        String username = mSharedPreferences.getString("username",null);

        findViewById(R.id.toolbar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        book_img = findViewById(R.id.book_img);
        book_title = findViewById(R.id.book_title);
        book_author = findViewById(R.id.book_author);
        book_details = findViewById(R.id.book_details);

        if (null != bookInfo){
            book_img.setImageResource(bookInfo.getBook_img());
            book_title.setText(bookInfo.getBook_title());
            book_author.setText(bookInfo.getBook_author());
            book_details.setText(bookInfo.getBook_details());
        }

//        String fiName = "res/raw/" + map.get(bookInfo.getBook_title()) + ".txt";
//        String textFromFile = FileUtil.readRawFile(this, fiName);


        HashMap<String, Integer> map = new HashMap<>();
        map.put("完美世界", R.raw.wmsj);
        map.put("庆余年", R.raw.qyn);
        map.put("明朝那些事儿", R.raw.mcnxsr);
        map.put("遮天", R.raw.zt);
        map.put("剑来", R.raw.jl);
        map.put("蛊真人", R.raw.gzr);
        map.put("十日终焉", R.raw.srzy);
        map.put("我在精神病院学斩神",R.raw.wzjsbyxzs);
        map.put("我不是戏神",R.raw.wbsxs);
        map.put("异兽迷城",R.raw.ysmc);




//        bookInfo.setBook_content(textFromFile);

        //加入到书架
        findViewById(R.id.addShelf).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                InputStream inputStream = getResources().openRawResource(map.get(bookInfo.getBook_title()));
                String st = getString(inputStream);

//                int row = ShelfDbHelper.getInstance(BookDetailsActivity.this).addShelf("lky", bookInfo.getBook_id(), bookInfo.getBook_img(), bookInfo.getBook_title(), bookInfo.getBook_author(), bookInfo.getBook_details(), FileUtil.getString(getResources().openRawResource(map.get(bookInfo.getBook_title()))));
                bookInfo.setBook_content(st);
                if (ShelfDbHelper.getInstance(BookDetailsActivity.this).isExists(username,bookInfo.getBook_title(), bookInfo.getBook_author())){
                    Toast.makeText(BookDetailsActivity.this, "该书已经存在~", Toast.LENGTH_SHORT).show();
                } else {
                    ShelfDbHelper.getInstance(BookDetailsActivity.this).addShelf(username, bookInfo.getBook_id(), bookInfo.getBook_img(), bookInfo.getBook_title(), bookInfo.getBook_author(), bookInfo.getBook_details(), bookInfo.getBook_content());
                    Toast.makeText(BookDetailsActivity.this, "添加成功", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }


    public String getString(InputStream inputStream) {
        InputStreamReader inputStreamReader = null;
        try {
            inputStreamReader = new InputStreamReader(inputStream, "utf-8");
        } catch (UnsupportedEncodingException e1) {
            e1.printStackTrace();
        }
        BufferedReader reader = new BufferedReader(inputStreamReader);
        StringBuffer sb = new StringBuffer("");
        String line;
        try {
            while ((line = reader.readLine()) != null) {
                sb.append(line);
                sb.append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }

}