package com.example.novel;

// ExampleService.kt
class ExampleService {
    fun fetchData(): List<String> {
        // 模拟数据获取
        return listOf("Item 1", "Item 2")
    }
}