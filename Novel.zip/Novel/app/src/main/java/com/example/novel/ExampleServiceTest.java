package com.example.novel;

public class ExampleServiceTest {

}
