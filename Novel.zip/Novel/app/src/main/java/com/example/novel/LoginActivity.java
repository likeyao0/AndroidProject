package com.example.novel;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.novel.database.BookDbHelper;
import com.example.novel.database.UserDbHelper;
import com.example.novel.entity.BookInfo;
import com.example.novel.entity.DataService;
import com.example.novel.model.UserInfo;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;

public class LoginActivity extends AppCompatActivity {

    private EditText et_userName;
    private EditText et_password;
    private CheckBox checkbox;
    private boolean is_login;
    private SharedPreferences mSharedPreferences;
    private SharedPreferences sharedPreferencesIsLogin;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        mSharedPreferences = getSharedPreferences("user",MODE_PRIVATE);

        is_login = mSharedPreferences.getBoolean("is_login", false);

        et_userName = findViewById(R.id.et_userName);
        et_password = findViewById(R.id.et_password);
        checkbox = findViewById(R.id.checkbox);

        if (is_login){
            String username = mSharedPreferences.getString("username", null);
            String password = mSharedPreferences.getString("password", null);
            et_userName.setText(username);
            et_password.setText(password);
            checkbox.setChecked(true);
        }

        //点击注册
        findViewById(R.id.registry).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //跳转注册页面
                Intent intent = new Intent(LoginActivity.this,RegisterActivity.class);
                startActivity(intent);
            }
        });

        //登录
        findViewById(R.id.login).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = et_userName.getText().toString();
                String password = et_password.getText().toString();

                if (TextUtils.isEmpty(userName) && TextUtils.isEmpty(password)) {
                    Toast.makeText(LoginActivity.this, "请输入用户名或密码", Toast.LENGTH_SHORT).show();
                } else {
//                    String name = mSharedPreferences.getString("userName",null);
//                    String pwd = mSharedPreferences.getString("password",null);

                    UserInfo login = UserDbHelper.getInstance(LoginActivity.this).login(userName);
                    if (login != null){
                        if (userName.equals(login.getUsername()) && password.equals(login.getPassword())){

                            SharedPreferences.Editor edit = mSharedPreferences.edit();
                            edit.putBoolean("is_login",is_login);
                            edit.putString("username",userName);
                            edit.putString("password",password);
//                            saveUsername(userName);
                            edit.apply();
//                            edit.commit();

                            //保存登录状态
                            sharedPreferencesIsLogin = getSharedPreferences("app_preferences", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferencesIsLogin.edit();
                            editor.putBoolean("isLoggedIn", true); // 保存登录状态
                            editor.apply();

                            Intent intent = new Intent(LoginActivity.this,MainActivity1.class);
                            startActivity(intent);
//                        Toast.makeText(LoginActivity.this, "登录成功", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(LoginActivity.this, "用户名或密码错误", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        Toast.makeText(LoginActivity.this, "该账号暂未注册", Toast.LENGTH_SHORT).show();
                    }


                }
            }
        });


        BookDbHelper.getInstance(LoginActivity.this).addBook(DataService.getListData(5).get(0));
        BookDbHelper.getInstance(LoginActivity.this).addBook(DataService.getListData(5).get(1));
        BookDbHelper.getInstance(LoginActivity.this).addBook(DataService.getListData(5).get(2));
        BookDbHelper.getInstance(LoginActivity.this).addBook(DataService.getListData(5).get(3));
        BookDbHelper.getInstance(LoginActivity.this).addBook(DataService.getListData(5).get(4));
        BookDbHelper.getInstance(LoginActivity.this).addBook(DataService.getListData(5).get(5));
        BookDbHelper.getInstance(LoginActivity.this).addBook(DataService.getListData(5).get(6));
        BookDbHelper.getInstance(LoginActivity.this).addBook(DataService.getListData(5).get(7));
        BookDbHelper.getInstance(LoginActivity.this).addBook(DataService.getListData(5).get(8));
        BookDbHelper.getInstance(LoginActivity.this).addBook(DataService.getListData(5).get(9));

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        //点击事件
        checkbox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                is_login = isChecked;
            }
        });
    }

}