package com.example.novel;

import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import com.example.novel.ui.FragmentBookCity;
import com.example.novel.ui.FragmentClassify;
import com.example.novel.ui.FragmentProfile;
import com.example.novel.ui.FragmentShelf;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity1 extends AppCompatActivity {
//
//    BookDetailFragment bookDetailFragment = new BookDetailFragment();
//    BookCityFragment bookCityFragment = new BookCityFragment();
//    HomeFragment homeFragment = new HomeFragment();
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//
//        getSupportFragmentManager().beginTransaction().add(R.id.layout,bookDetailFragment).commit();
//        getSupportFragmentManager().beginTransaction().add(R.id.layout,bookCityFragment).commit();
//        getSupportFragmentManager().beginTransaction().add(R.id.layout,homeFragment).commit();
//
//        getSupportFragmentManager().beginTransaction().hide(bookCityFragment).hide(homeFragment).show(bookDetailFragment).commit();
//
//        findViewById(R.id.constraintLayout2).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                getSupportFragmentManager().beginTransaction().hide(bookCityFragment).hide(homeFragment).show(bookDetailFragment).commit();
//
//            }
//        });
//        findViewById(R.id.constraintLayout).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                getSupportFragmentManager().beginTransaction().hide(bookDetailFragment).hide(homeFragment).show(bookCityFragment).commit();
//
//            }
//        });
//        findViewById(R.id.constraintLayout3).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                getSupportFragmentManager().beginTransaction().hide(bookCityFragment).hide(bookDetailFragment).show(homeFragment).commit();
//
//            }
//        });
//    }
    private BottomNavigationView bottomNavigationView;
//    private ShelfFragment shelfFragment;
//    private BookCityFragment bookCityFragment;
//    private BookDetailFragment bookDetailFragment;
//    private profileFragment profileFragment;

    private FragmentShelf fragmentShelf;
    private FragmentBookCity fragmentBookCity;
    private FragmentClassify fragmentClassify;
    private FragmentProfile fragmentProfile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

//        BookDbHelper.getInstance(MainActivity1.this).addBook(new BookInfo());

//        初始化控件
        bottomNavigationView = findViewById(R.id.bottomNavigationView);

        //默认首页选中
        selectedFragment(0);

        //点击事件
        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                if (item.getItemId() == R.id.shelf){
                    selectedFragment(0);
                } else if (item.getItemId() == R.id.profile){
                    selectedFragment(3);
                } else if (item.getItemId() == R.id.bookCity) {
                    selectedFragment(1);
                } else
                    selectedFragment(2);
                return true;
            }
        });

    }

    private void selectedFragment(int position) {
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        hideFragment(fragmentTransaction);
        if(position == 0){
            if (fragmentShelf == null){
                fragmentShelf = new FragmentShelf();
                fragmentTransaction.add(R.id.content,fragmentShelf);
            }else {
                fragmentTransaction.show(fragmentShelf);
                fragmentShelf.loadData();
            }
        } else if (position == 1){
            if (fragmentBookCity == null){
                fragmentBookCity = new FragmentBookCity();
                fragmentTransaction.add(R.id.content,fragmentBookCity);
            } else {
                fragmentTransaction.show(fragmentBookCity);
            }
        } else if (position == 2){
            if (fragmentClassify == null){
                fragmentClassify = new FragmentClassify();
                fragmentTransaction.add(R.id.content,fragmentClassify);
            } else {
                fragmentTransaction.show(fragmentClassify);
            }
        } else {
            if (fragmentProfile == null){
                fragmentProfile = new FragmentProfile();
                fragmentTransaction.add(R.id.content,fragmentProfile);
            } else {
                fragmentTransaction.show(fragmentProfile);
            }
        }

        fragmentTransaction.commit();

    }
    private void hideFragment(FragmentTransaction fragmentTransaction){
        if(fragmentShelf != null){
            fragmentTransaction.hide(fragmentShelf);
        }
        if(fragmentBookCity != null){
            fragmentTransaction.hide(fragmentBookCity);
        }
        if(fragmentClassify != null){
            fragmentTransaction.hide(fragmentClassify);
        }
        if(fragmentProfile != null){
            fragmentTransaction.hide(fragmentProfile);
        }
    }
}