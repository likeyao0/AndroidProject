package com.example.novel;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.novel.database.BookDbHelper;
import com.example.novel.database.UserDbHelper;

public class RegisterActivity extends AppCompatActivity {

    private EditText et_userName;
    private EditText et_password;

//    private SharedPreferences mSharePreferences;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_register);

        //获取mSharePreferences
//        mSharePreferences = getSharedPreferences("user",MODE_PRIVATE);

        et_userName = findViewById(R.id.et_userName);
        et_password = findViewById(R.id.et_password);

        //点击回退至登录
        findViewById(R.id.toolbar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        //点击注册
        findViewById(R.id.register).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String userName = et_userName.getText().toString();
                String password = et_password.getText().toString();

                if (TextUtils.isEmpty(userName) && TextUtils.isEmpty(password)) {
                    Toast.makeText(RegisterActivity.this, "请输入用户名或密码", Toast.LENGTH_SHORT).show();
                } else {
//                    SharedPreferences.Editor edit = mSharePreferences.edit();
//                    edit.putString("userName",userName);
//                    edit.putString("password",password);
//                    edit.commit();
                    int row = UserDbHelper.getInstance(RegisterActivity.this).register(userName,password," 暂无");

                    if (row > 0){
                        Toast.makeText(RegisterActivity.this, "注册成功，请登录", Toast.LENGTH_SHORT).show();
                        finish();
                    } else {
                        Toast.makeText(RegisterActivity.this, "该用户名已经存在，请输入其他内容", Toast.LENGTH_SHORT).show();
                    }



//                    Toast.makeText(RegisterActivity.this, "注册成功，请登录", Toast.LENGTH_SHORT).show();
//                    finish();
                }
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}