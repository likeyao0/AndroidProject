package com.example.novel;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.novel.database.UserDbHelper;
import com.example.novel.model.UserInfo;

public class UpdateNicknameActivity extends AppCompatActivity {

    private EditText et_new_nickname;
    private SharedPreferences mSharedPreferences;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update_nickname);

        findViewById(R.id.toolbar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        et_new_nickname = findViewById(R.id.et_new_nickname);
        mSharedPreferences = getSharedPreferences("user", MODE_PRIVATE);
        String username = mSharedPreferences.getString("username",null);

        findViewById(R.id.btn_update_nickname).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String new_nickname = et_new_nickname.getText().toString();

                if (TextUtils.isEmpty(new_nickname)) {
                    Toast.makeText(UpdateNicknameActivity.this, "签名不能为空", Toast.LENGTH_SHORT).show();
                } else {
                    UserInfo userInfo = UserInfo.getUserInfo(UpdateNicknameActivity.this,username);
                    if (null != userInfo){
                        int row = UserDbHelper.getInstance(UpdateNicknameActivity.this).updateNickname(userInfo.getUsername(), new_nickname);
                        if (row>0){
                            Toast.makeText(UpdateNicknameActivity.this, "修改签名成功", Toast.LENGTH_SHORT).show();
                            Intent returnIntent = new Intent();
                            returnIntent.putExtra("nickname",new_nickname);
                            setResult(1001,returnIntent);
                            finish();
                        } else {
                            Toast.makeText(UpdateNicknameActivity.this, "修改失败", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}