package com.example.novel;

import android.annotation.SuppressLint;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.novel.database.UserDbHelper;
import com.example.novel.model.UserInfo;

public class UpdatePwdActivity extends AppCompatActivity {

    private EditText et_new_password;
    private EditText et_confirm_password;
    private SharedPreferences mSharedPreferences;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_update_pwd);

        findViewById(R.id.toolbar).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        et_new_password = findViewById(R.id.et_new_password);
        et_confirm_password = findViewById(R.id.et_confirm_password);
        mSharedPreferences = getSharedPreferences("user", MODE_PRIVATE);
        String username = mSharedPreferences.getString("username",null);

        findViewById(R.id.btn_update_pwd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String new_pwd = et_new_password.getText().toString();
                String confirm_pwd = et_confirm_password.getText().toString();
                UserInfo userInfo = UserInfo.getUserInfo(UpdatePwdActivity.this,username);

                if (TextUtils.isEmpty(new_pwd) || TextUtils.isEmpty(confirm_pwd)) {
                    Toast.makeText(UpdatePwdActivity.this, "密码不能为空", Toast.LENGTH_SHORT).show();
                } else if (!new_pwd.equals(confirm_pwd)) {
                    Toast.makeText(UpdatePwdActivity.this, "新密码和确认密码不一致", Toast.LENGTH_SHORT).show();
                } else if (userInfo.getPassword().equals(new_pwd)){
                    Toast.makeText(UpdatePwdActivity.this, "新密码与旧密码一致", Toast.LENGTH_SHORT).show();
                } else {
                    if (null != userInfo){
                        int row = UserDbHelper.getInstance(UpdatePwdActivity.this).updatePwd(userInfo.getUsername(), new_pwd);
                        if (row>0){
                            Toast.makeText(UpdatePwdActivity.this, "修改密码成功，请重新登录", Toast.LENGTH_SHORT).show();
                            setResult(1000);
                            finish();
                        } else {
                            Toast.makeText(UpdatePwdActivity.this, "修改失败", Toast.LENGTH_SHORT).show();
                        }
                    }
                }

            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

}