package com.example.novel;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.View;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class WelcomeActivity extends AppCompatActivity {

    private TextView tv_countdown;
    private CountDownTimer countDownTimer;
    private long timeLeftInMillis = 4000;
    private SharedPreferences sharedPreferencesIsLogin;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_welcom);

        tv_countdown = findViewById(R.id.tv_countdown);

        //判断是否登录
        sharedPreferencesIsLogin = getSharedPreferences("app_preferences", Context.MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferencesIsLogin.getBoolean("isLoggedIn", false); // 获取登录状态，默认为false


        findViewById(R.id.skip_).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isLoggedIn) {
                    Intent intent = new Intent(WelcomeActivity.this, MainActivity1.class);
                    startActivity(intent);
                }else {
                    startActivity(new Intent(WelcomeActivity.this, LoginActivity.class));
                }
                finish();
            }
        });

        startCountdown();

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void startCountdown() {
        countDownTimer = new CountDownTimer(timeLeftInMillis,1000) {

            @Override
            public void onTick(long l) {
                timeLeftInMillis = l;
                int secondsRemaining = (int) (l/1000);
                tv_countdown.setText(secondsRemaining + " s 跳过");
            }

            @Override
            public void onFinish() {
                sharedPreferencesIsLogin = getSharedPreferences("app_preferences", Context.MODE_PRIVATE);
                boolean isLoggedIn = sharedPreferencesIsLogin.getBoolean("isLoggedIn", false); // 获取登录状态，默认为false
                if (isLoggedIn) {
                    Intent intent = new Intent(WelcomeActivity.this, MainActivity1.class);
                    startActivity(intent);
                } else {
                    startActivity(new Intent(WelcomeActivity.this, LoginActivity.class));
                }
                finish();
            }
        }.start();
    }

    @Override
    protected void onDestroy(){
        super.onDestroy();
        if (countDownTimer != null) {
            countDownTimer.cancel();
        }
    }

}