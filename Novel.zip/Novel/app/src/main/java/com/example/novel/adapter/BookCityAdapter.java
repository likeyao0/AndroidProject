package com.example.novel.adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.novel.R;
import com.example.novel.entity.BookInfo;
import com.example.novel.entity.ShelfInfo;

import java.util.ArrayList;
import java.util.List;

public class BookCityAdapter extends RecyclerView.Adapter<BookCityAdapter.MyHolder> {

    private List<BookInfo> mBookInfoList = new ArrayList<>();
    public void setBookInfoList(List<BookInfo> list){
        this.mBookInfoList = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bookcity_list_item, null);

        return new MyHolder(view);
    }

    @SuppressLint("RecyclerView")
    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {
        BookInfo shelfInfo = mBookInfoList.get(position);

        holder.shelf_img.setImageResource(shelfInfo.getBook_img());
        holder.shelf_title.setText(shelfInfo.getBook_title());
        holder.shelf_author.setText(shelfInfo.getBook_author());
        holder.shelf_details.setText(shelfInfo.getBook_details());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (null != mOnItemClickListener){
                    mOnItemClickListener.onItemClick(shelfInfo,position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {
        return mBookInfoList.size();
    }

    static class MyHolder extends RecyclerView.ViewHolder{

        ImageView shelf_img;
        TextView shelf_title;
        TextView shelf_author;
        TextView shelf_details;

        public MyHolder(@NonNull View itemView) {
            super(itemView);

            shelf_img = itemView.findViewById(R.id.Shelf_img);
            shelf_title = itemView.findViewById(R.id.Shelf_title);
            shelf_author = itemView.findViewById(R.id.Shelf_author);
            shelf_details = itemView.findViewById(R.id.Shelf_details);

        }
    }

    private RightListAdapter.onItemClickListener mOnItemClickListener;

    public void setmOnItemClickListener(RightListAdapter.onItemClickListener mOnItemClickListener_C) {
        mOnItemClickListener = mOnItemClickListener_C;
    }

    public interface onItemClickListener{
        void onItemClick(BookInfo bookInfo);
    }
}
