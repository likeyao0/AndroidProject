package com.example.novel.adapter;

import android.annotation.SuppressLint;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.ListAdapter;
import androidx.recyclerview.widget.RecyclerView;

import com.example.novel.BookDetailsActivity;
import com.example.novel.R;
import com.example.novel.entity.BookInfo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class RightListAdapter extends RecyclerView.Adapter<RightListAdapter.MyHolder> {

    private List<BookInfo> mBookInfos = new ArrayList<>();

    public void setListData(List<BookInfo> list){
        this.mBookInfos = list;
        notifyDataSetChanged();
    }


    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.right_list_item, null);
        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, @SuppressLint("RecyclerView") int position) {

        BookInfo bookInfo = mBookInfos.get(position);

        holder.Book_img.setImageResource(bookInfo.getBook_img());
        holder.Book_title.setText(bookInfo.getBook_title());
        holder.Book_author.setText(bookInfo.getBook_author());
        holder.Book_details.setText(bookInfo.getBook_details());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (null != mOnItemClickListener){
                    mOnItemClickListener.onItemClick(bookInfo,position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {

        return mBookInfos.size();
    }

    static class MyHolder extends RecyclerView.ViewHolder{

        ImageView Book_img;
        TextView Book_title;
        TextView Book_author;
        TextView Book_details;


        private MyHolder(@NonNull View itemView){
            super(itemView);
            Book_img = itemView.findViewById(R.id.Book_img);
            Book_title = itemView.findViewById(R.id.Book_title);
            Book_author = itemView.findViewById(R.id.Book_author);
            Book_details = itemView.findViewById(R.id.Book_details);

        }
    }
    private onItemClickListener mOnItemClickListener;

    public void setmOnItemClickListener(onItemClickListener mOnItemClickListener_l) {
        mOnItemClickListener = mOnItemClickListener_l;
    }

    public interface onItemClickListener{
        void onItemClick(BookInfo bookInfo,int position);
    }
}
