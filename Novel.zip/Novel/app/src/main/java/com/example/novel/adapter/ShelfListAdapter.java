package com.example.novel.adapter;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.novel.BookDetailsActivity;
import com.example.novel.R;
import com.example.novel.entity.BookInfo;
import com.example.novel.entity.ShelfInfo;

import java.util.ArrayList;
import java.util.List;

public class ShelfListAdapter extends RecyclerView.Adapter<ShelfListAdapter.MyHolder> {

    private List<ShelfInfo> mBookInfoList = new ArrayList<>();

    public void setBookInfoList(List<ShelfInfo> list){
        this.mBookInfoList = list;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.shelf_list_item, null);
        return new MyHolder(view);
    }

    @SuppressLint("RecyclerView")
    @Override
    public void onBindViewHolder(@NonNull MyHolder holder, int position) {

        ShelfInfo shelfInfo = mBookInfoList.get(position);
        holder.shelf_img.setImageResource(shelfInfo.getBook_img());
        holder.shelf_title.setText(shelfInfo.getBook_title());
        holder.shelf_author.setText(shelfInfo.getBook_author());
        holder.shelf_details.setText(shelfInfo.getBook_details());


        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (null != mOnItemClickListener){
                    mOnItemClickListener.onReadingOnClick(shelfInfo,position);
                }
            }
        });

        holder.more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(view.getContext(), "暂无更多信息", Toast.LENGTH_SHORT).show();
            }
        });

        holder.itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                if (mOnItemClickListener != null){
                    mOnItemClickListener.deOnClick(shelfInfo,position);
                }
                return true;
            }
        });

//        if (shelfInfo)
    }

    @Override
    public int getItemCount() {
        return mBookInfoList.size();
    }


    static class MyHolder extends RecyclerView.ViewHolder{

        ImageView shelf_img;
        TextView shelf_title;
        TextView shelf_author;
        TextView shelf_details;
        View reading;
        ImageView more;
//        ImageView shelf_top;


        public MyHolder(@NonNull View itemView){
            super(itemView);

            shelf_img = itemView.findViewById(R.id.Shelf_img);
            shelf_title = itemView.findViewById(R.id.Shelf_title);
            shelf_author = itemView.findViewById(R.id.Shelf_author);
            shelf_details = itemView.findViewById(R.id.Shelf_details);
            reading = itemView.findViewById(R.id.reading);
            more = itemView.findViewById(R.id.more);
//            shelf_top = itemView.findViewById(R.id.shelf_top);


        }
    }

    private onItemClickListener mOnItemClickListener;

    public void setmOnItemClickListener(onItemClickListener mOnItemClickListener) {
        this.mOnItemClickListener = mOnItemClickListener;
    }

    public interface onItemClickListener{
        void onReadingOnClick(ShelfInfo shelfInfo,int position);
        void deOnClick(ShelfInfo shelfInfo,int position);
    }

}
