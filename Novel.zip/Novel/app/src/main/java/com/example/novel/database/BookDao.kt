package com.example.novel.database

//数据访问对象（DAO），用于执行与书籍相关的数据库操作。
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.novel.model.Book
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {

    // 查询所有书籍
    @Query("SELECT * FROM books")
    fun getAllBooks(): Flow<List<Book>>

    // 根据ID查询书籍
    @Query("SELECT * FROM books WHERE id = :bookId")
    fun getBookById(bookId: Int): Book?

    // 插入书籍
    @Insert
    fun insertBook(book: Book)

    // 更新书籍
    @Update
    fun updateBook(book: Book)

    // 删除书籍
    @Query("DELETE FROM books WHERE id = :bookId")
    fun deleteBook(bookId: Int)
}