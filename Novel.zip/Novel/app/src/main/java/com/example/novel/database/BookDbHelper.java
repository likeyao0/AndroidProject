package com.example.novel.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.novel.entity.BookCityInfo;
import com.example.novel.entity.BookInfo;
import com.example.novel.entity.DataService;
import com.example.novel.entity.ShelfInfo;

import java.util.ArrayList;
import java.util.List;

public class BookDbHelper extends SQLiteOpenHelper {
    private static BookDbHelper sHelper;
    private static final String DB_NAME = "book.db";
    private static final int VERSION = 1;

    public BookDbHelper (@Nullable Context context, @Nullable String name , @Nullable SQLiteDatabase.CursorFactory factory , @Nullable int version) {
        super(context,name,factory,version);
    }

    public synchronized static BookDbHelper getInstance(Context context){
        if (null == sHelper){
            sHelper = new BookDbHelper(context,DB_NAME,null,VERSION);
        }
        return sHelper;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table book_table(book_id integer primary key autoincrement,"+
                "book_img integer," +
                "book_title text,"+
                "book_author text,"+
                "book_details text,"+
                "book_content text" +
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    public void addBook(BookInfo bookInfo){
        if (!isExists(bookInfo.getBook_title(),bookInfo.getBook_author())){
            SQLiteDatabase db = getReadableDatabase();
            ContentValues values = new ContentValues();

            values.put("book_img",bookInfo.getBook_img());
            values.put("book_title",bookInfo.getBook_title());
            values.put("book_author",bookInfo.getBook_author());
            values.put("book_details",bookInfo.getBook_details());
            values.put("book_content",bookInfo.getBook_content());

            String nullColumnHack = "values(null,?,?,?,?,?)";

            int insert = (int) db.insert("book_table", nullColumnHack,values);
            db.close();
        }
    }

    @SuppressLint("Range")
    public List<BookInfo> queryBookList(String bookTitle){

        SQLiteDatabase db = getReadableDatabase();
        List<BookInfo> list = new ArrayList<>();
        String sql = "select book_id,book_img,book_title,book_author,book_details,book_content from book_table where book_title LIKE ?";
        String[] selectionArgs = {"%" + bookTitle + "%"};
        Cursor cursor = db.rawQuery(sql,selectionArgs);
        while (cursor.moveToNext()){
            int book_Id = cursor.getInt(cursor.getColumnIndex("book_id"));
            int book_img = cursor.getInt(cursor.getColumnIndex("book_img"));
            String  book_title = cursor.getString(cursor.getColumnIndex("book_title"));
            String book_author = cursor.getString(cursor.getColumnIndex("book_author"));
            String book_details = cursor.getString(cursor.getColumnIndex("book_details"));
            String book_content = cursor.getString(cursor.getColumnIndex("book_content"));
            list.add(new BookInfo(book_Id,book_title,book_author,book_details,book_img,book_content));
        }
        return list;
    }

    @SuppressLint("Range")
    public boolean isExists(String bookTitle, String author){

        SQLiteDatabase db = getReadableDatabase();
        String sql = "select book_id,book_title,book_author,book_details,book_img,book_content from book_table where book_title=? and book_author=?";
        String[] selectionArgs = {bookTitle, author};
        Cursor cursor = db.rawQuery(sql,selectionArgs);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

//    @SuppressLint("Range")
//    public List<BookInfo> queryBookList(String bookTitle){
//
//        SQLiteDatabase db = getReadableDatabase();
//        List<BookInfo> list = new ArrayList<>();
//        String sql = "select book_id,book_title,book_author,book_details,book_img,book_content from book_table where book_title=?";
//        String[] selectionArgs = {bookTitle};
//        Cursor cursor = db.rawQuery(sql,selectionArgs);
//        while (cursor.moveToNext()){
//            int book_id = cursor.getInt(cursor.getColumnIndex("book_id"));
//            int book_img = cursor.getInt(cursor.getColumnIndex("book_img"));
//            String  book_title = cursor.getString(cursor.getColumnIndex("book_title"));
//            String book_author = cursor.getString(cursor.getColumnIndex("book_author"));
//            String book_details = cursor.getString(cursor.getColumnIndex("book_details"));
//            String book_content = cursor.getString(cursor.getColumnIndex("book_content"));
//            list.add(new BookInfo(book_id,book_title,book_author,book_details,book_img,book_content));
//        }
//        return list;
//    }

}
