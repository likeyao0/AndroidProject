package com.example.novel.database

//定义了应用程序的数据库，包括其版本和包含的DAO。
import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.novel.model.Book
import com.example.novel.model.User

// 使用RoomDatabase抽象类来定义数据库
@Database(entities = [Book::class, User::class], version = 1)
abstract class AppDatabase : RoomDatabase() {

    // 获取BookDao的实例
    abstract fun bookDao(): BookDao

    // 获取UserDao的实例
    abstract fun userDao(): UserDao

    // 获取ReadHistoryDao的实例
    abstract fun readHistoryDao(): ReadHistoryDao

    // Companion object to hold the database instance
    companion object {
        // Variable to hold the database instance
        private var instance: AppDatabase? = null

        // Method to get the database instance
        fun getDatabase(context: Context): AppDatabase {
            // If the instance is null, synchronize the block and check again
            return instance ?: synchronized(this) {
                instance ?: buildDatabase(context).also { instance = it }
            }
        }

        // Private method to build the database
        private fun buildDatabase(context: Context): AppDatabase {
            return Room.databaseBuilder(
                context.applicationContext, // Get the application context
                AppDatabase::class.java,   // The class of the database
                "novel_database"           // The name of the database
            ).build()
        }
    }
}
