package com.example.novel.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.novel.model.Book
import com.example.novel.model.ReadHistory
import kotlinx.coroutines.flow.Flow

@Dao
interface ReadHistoryDao {
    // 查询所有历史记录
    @Query("SELECT * FROM read_history")
    fun getReadHistory(): Flow<List<Book>>
}