package com.example.novel.database;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import com.example.novel.entity.ShelfInfo;

import java.util.ArrayList;
import java.util.List;

public class ShelfDbHelper extends SQLiteOpenHelper {
    private static ShelfDbHelper sHelper;
    private static final String DB_NAME = "shelf.db";
    private static final int VERSION = 1;

    public ShelfDbHelper (@Nullable Context context, @Nullable String name , @Nullable SQLiteDatabase.CursorFactory factory , @Nullable int version) {
        super(context,name,factory,version);
    }
    public synchronized static ShelfDbHelper getInstance(Context context){
        if (null == sHelper){
            sHelper = new ShelfDbHelper(context,DB_NAME,null,VERSION);
        }
        return sHelper;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("create table shelf_table(shelf_user_id integer primary key autoincrement,"+
                "username text," +
                "book_id text," +
                "book_img integer," +
                "book_title text,"+
                "book_author text,"+
                "book_details text,"+
                "book_content text,"+
                "book_count integer"+
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase,int i, int i1){

    }

    public int addShelf(String username,int book_id,int book_img,String book_title,String book_author,String book_details,String book_content){

        ShelfInfo addShelf = isAddShelf(username, book_id);
        boolean isExists = isExists(username,book_title,book_author);
        if (addShelf == null){
            SQLiteDatabase db = getReadableDatabase();
            ContentValues values = new ContentValues();


            values.put("username",username);
            values.put("book_id",book_id);
            values.put("book_img",book_img);
            values.put("book_title",book_title);
            values.put("book_author",book_author);
            values.put("book_details",book_details);
            values.put("book_content",book_content);
            values.put("book_count",1);
//            values.put("book_top",book_top);


            String nullColumnHack = "values(null,?,?,?,?,?,?,?,?)";

            int insert = (int) db.insert("shelf_table", nullColumnHack,values);
//            db.close();
            return insert;
        } else {
            return updateShelf(addShelf.getShelf_user_id(),addShelf);
        }
    }

    public int updateShelf(int shelf_user_id, ShelfInfo shelfInfo){

        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("book_count",shelfInfo.getBook_count()+1);

        int update = db.update("shelf_table",values,"shelf_user_id=?",new  String[]{shelf_user_id+""});
//        db.close();
        return update;
    }

    @SuppressLint("Range")
    public ShelfInfo isAddShelf(String username,int book_id){
        SQLiteDatabase db = getReadableDatabase();
        ShelfInfo shelfInfo = null;
        String sql = "select shelf_user_id,username,book_id,book_img,book_title,book_author,book_details,book_content,book_count from shelf_table where username=? and book_id=?";
        String[] selectionArgs = {username,book_id+""};
        Cursor cursor = db.rawQuery(sql,selectionArgs);
        if (cursor.moveToNext()) {
            int shelf_user_id = cursor.getInt(cursor.getColumnIndex("shelf_user_id"));
            String name = cursor.getString(cursor.getColumnIndex("username"));
            int book_Id = cursor.getInt(cursor.getColumnIndex("book_id"));
            int book_img = cursor.getInt(cursor.getColumnIndex("book_img"));
            String  book_title = cursor.getString(cursor.getColumnIndex("book_title"));
            String book_author = cursor.getString(cursor.getColumnIndex("book_author"));
            String book_details = cursor.getString(cursor.getColumnIndex("book_details"));
            String book_content = cursor.getString(cursor.getColumnIndex("book_content"));
            int book_count = cursor.getInt(cursor.getColumnIndex("book_count"));
//            int book_top = cursor.getInt(cursor.getColumnIndex("book_top"));


            shelfInfo = new ShelfInfo(name,shelf_user_id,book_Id,book_img,book_title,book_author,book_details,book_content,book_count);
        }
        cursor.close();
//        db.close();
        return shelfInfo;
    }

    @SuppressLint("Range")
    public boolean isExists(String username,String bookTitle, String author){

        SQLiteDatabase db = getReadableDatabase();
        String sql = "select book_id,book_title,book_author,book_details,book_img,book_content from shelf_table where username=? and book_title=? and book_author=?";
        String[] selectionArgs = {username, bookTitle, author};
        Cursor cursor = db.rawQuery(sql,selectionArgs);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
//        db.close();
        return exists;
    }

    @SuppressLint("Range")
    public List<ShelfInfo> queryShelfList(String username){

        SQLiteDatabase db = getReadableDatabase();
        List<ShelfInfo> list = new ArrayList<>();
        String sql = "select shelf_user_id,username,book_id,book_img,book_title,book_author,book_details,book_content,book_count from shelf_table where username=?";
        String[] selectionArgs = {username};
        Cursor cursor = db.rawQuery(sql,selectionArgs);
        while (cursor.moveToNext()){
            int shelf_user_id = cursor.getInt(cursor.getColumnIndex("shelf_user_id"));
            String name = cursor.getString(cursor.getColumnIndex("username"));
            int book_Id = cursor.getInt(cursor.getColumnIndex("book_id"));
            int book_img = cursor.getInt(cursor.getColumnIndex("book_img"));
            String  book_title = cursor.getString(cursor.getColumnIndex("book_title"));
            String book_author = cursor.getString(cursor.getColumnIndex("book_author"));
            String book_details = cursor.getString(cursor.getColumnIndex("book_details"));
            String book_content = cursor.getString(cursor.getColumnIndex("book_content"));
            int book_count = cursor.getInt(cursor.getColumnIndex("book_count"));
//            int book_top = cursor.getInt(cursor.getColumnIndex("book_top"));
            list.add(new ShelfInfo(name,shelf_user_id,book_Id,book_img,book_title,book_author,book_details,book_content,book_count));
        }
        return list;
    }

    public int delete(String shelf_user_id){
        SQLiteDatabase db = getWritableDatabase();
        int delete = db.delete("shelf_table","shelf_user_id=?",new String[]{shelf_user_id});

//        db.close();
        return delete;
    }

    public int delete_User_All(String username){
        SQLiteDatabase db = getWritableDatabase();
        int delete = db.delete("shelf_table","username=?",new String[]{username});

//        db.close();
        return delete;
    }

}
