package com.example.novel.database

//数据访问对象，用于执行与用户相关的数据库操作。
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.novel.model.User

@Dao
interface UserDao {

    // 查询所有用户
    @Query("SELECT * FROM users")
    fun getAllUsers(): List<User>

    // 根据ID查询用户
    @Query("SELECT * FROM users WHERE id = :userId")
    fun getUserById(userId: Int): User?

    // 根据用户名查询用户
    @Query("SELECT * FROM users WHERE username = :username")
    fun getUserByUsername(username: String): User?

    // 插入用户
    @Insert
    fun insertUser(user: User)

    // 更新用户
    @Update
    fun updateUser(user: User)

    // 删除用户
    @Query("DELETE FROM users WHERE id = :userId")
    fun deleteUser(userId: Int)
}