package com.example.novel.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class BookInfo implements Serializable {
    private int Book_id;
    private String Book_title;
    private String Book_author;
    private String Book_details;
    private int Book_img;
    private String Book_content;

    public String getBook_content() {
        return Book_content;
    }

    public void setBook_content(String book_content) {
        Book_content = book_content;
    }

    public String getBook_author() {
        return Book_author;
    }

    public void setBook_author(String book_author) {
        Book_author = book_author;
    }

    public int getBook_id() {
        return Book_id;
    }

    public void setBook_id(int book_id) {
        Book_id = book_id;
    }

    public String getBook_title() {
        return Book_title;
    }

    public void setBook_title(String book_title) {
        Book_title = book_title;
    }

    public String getBook_details() {
        return Book_details;
    }

    public void setBook_details(String book_details) {
        Book_details = book_details;
    }

    public int getBook_img() {
        return Book_img;
    }

    public void setBook_img(int book_img) {
        Book_img = book_img;
    }

    public BookInfo(String book_title, String book_author, String book_details, int book_img, String book_content) {
        Book_title = book_title;
        Book_author = book_author;
        Book_details = book_details;
        Book_img = book_img;
        Book_content = book_content;
    }

    public BookInfo(int book_id, String book_title, String book_author, String book_details, int book_img, String book_content) {
        Book_id = book_id;
        Book_title = book_title;
        Book_author = book_author;
        Book_details = book_details;
        Book_img = book_img;
        Book_content = book_content;
    }

    public BookInfo(BookInfo bookInfo){
        Book_title = bookInfo.getBook_title();
        Book_author = bookInfo.getBook_author();
        Book_details = bookInfo.getBook_details();
        Book_img = bookInfo.getBook_img();
        Book_content = bookInfo.getBook_content();
    }
}
