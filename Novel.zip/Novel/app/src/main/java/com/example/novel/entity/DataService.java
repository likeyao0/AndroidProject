package com.example.novel.entity;

import android.content.ContentValues;
import android.content.Context;

import com.example.novel.BookDetailsActivity;
import com.example.novel.R;
import com.example.novel.database.BookDbHelper;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class DataService {

    public static List<BookInfo> getListData(int position){

        List<BookInfo> list = new ArrayList<>();
        List<BookInfo> Alllist = new ArrayList<>();

        HashMap<String, String> map = new HashMap<>();
        map.put("完美世界", "res/raw/wmsj.txt");
        map.put("庆余年", "res/raw/qyn.txt");
        map.put("明朝那些事儿", "res/raw/mcnxsr.txt");
        map.put("遮天", "res/raw/zt.txt");
        map.put("剑来", "res/raw/jl.txt");
        map.put("蛊真人", "res/raw/gzr.txt");
        map.put("十日终焉", "res/raw/srzy.txt");
        map.put("我在精神病院学斩神","res/raw/wzjsbyxzs.txt");
        map.put("我不是戏神","res/raw/wbsxs.txt");
        map.put("异兽迷城","res/raw/ysmc.txt");


        String filePath;
        String fileContent;

        if (position == 0){
            filePath = map.get("庆余年");
            fileContent = readFileContent(filePath, "utf-8");
            list.add(new BookInfo(4, "庆余年","猫腻","积善之家，必有余庆，留余庆，留余庆，忽遇恩人；幸娘亲，幸娘亲，积得阴功。劝人生，济困扶穷……而谁可知，人生于世，上承余庆，终究却是要自己做出道路抉择，正是所谓岔枝发：\n" +
                    "东风携云雨，幼藤吐新芽。\n" +
                    "急催如颦鼓，洗尽茸与华。\n" +
                    "且待朝阳至，绿遍庭中架。\n" +
                    "更盼黄叶时，采得数枚瓜。",R.mipmap.img_qyn,fileContent));
            filePath = map.get("明朝那些事儿");
            fileContent = readFileContent(filePath, "utf-8");
            list.add(new BookInfo(5, "明朝那些事儿","当年明月","《明朝那些事儿》主要讲述的是从1344年到1644年这三百年间关于明朝的一些故事。以史料为基础，以年代和具体人物为主线，并加入了小说的笔法，语言幽默风趣。对明朝十七帝和其他王公权贵和小人物的命运进行全景展示，尤其对官场政治、战争、帝王心术着墨最多，并加入对当时政治经济制度、人伦道德的演义。它以一种网络语言向读者娓娓道出明朝三百多年的历史故事、人物。其中原本在历史中陌生、模糊的历史人物在书中一个个变得鲜活起来。《明朝那些事儿》为我们解读历史中的另一面，让历史变成一部活生生的生活故事。" ,R.mipmap.img_mcnxs,fileContent));
            return list;
        } else if (position == 1) {
            filePath = map.get("完美世界");
            fileContent = readFileContent(filePath, "utf-8");
            list.add(new BookInfo(0, "完美世界","辰东",
                    "一粒尘可填海，一根草斩尽日月星辰，弹指间天翻地覆。\n" +
                    "群雄并起，万族林立，诸圣争霸，乱天动地。问苍茫大地，谁主沉浮？！\n" +
                    "一个少年从大荒中走出，一切从这里开始……",R.mipmap.img_wmsj,fileContent));
            filePath = map.get("遮天");
            fileContent = readFileContent(filePath, "utf-8");
            list.add(new BookInfo(1, "遮天","辰东","冰冷与黑暗并存的宇宙深处，九具庞大的龙尸拉着一口青铜古棺，亘古长存。\n" +
                    "这是太空探测器在枯寂的宇宙中捕捉到的一幅极其震撼的画面。\n" +
                    "九龙拉棺，究竟是回到了上古，还是来到了星空的彼岸？\n" +
                    "一个浩大的仙侠世界，光怪陆离，神秘无尽。\n" +
                    "热血似火山沸腾，激情若瀚海汹涌，欲望如深渊无止境……\n" +
                    "登天路，踏歌行，弹指遮天。",R.mipmap.img_zt,fileContent));
            filePath = map.get("剑来");
            fileContent = readFileContent(filePath, "utf-8");
            list.add(new BookInfo(2, "剑来","烽火戏诸侯","大千世界，无奇不有。我陈平安，唯有一剑，可搬山，断江，倒海，降妖，镇魔，敕神，摘星，摧城，开天！我叫陈平安，平平安安的平安，我是一名剑客。走北俱芦洲，问剑正阳山，赴大骊皇城，至蛮荒天下。斩大妖，了恩怨，会旧人，归故乡。刻字剑气长城，陈平安再开青萍剑宗！",R.mipmap.img_jl,fileContent));
            filePath = map.get("蛊真人");
            fileContent = readFileContent(filePath, "utf-8");
            list.add(new BookInfo(6, "蛊真人","真人",
                    "人是万物之灵，蛊是天地真精。\n" +
                            "三观不正，枭魔重生。\n" +
                            "昔日旧梦，同名新作。\n" +
                            "一个穿越者不断重生的故事。",R.mipmap.img_gzr, fileContent));

            return list;
        } else if (position == 2) {
            filePath = map.get("十日终焉");
            fileContent = readFileContent(filePath, "utf-8");
            list.add(new BookInfo(3, "十日终焉","杀虫队队员","（不后宫，不套路，不无敌，不系统，不无脑，不爽文，介意者慎入。） 当我以为这只是寻常的一天时，却发现自己被捉到了终焉之地。 当我以为只需要不断的参加死亡游戏就可以逃脱时，却发现众人开始觉醒超自然之力。 当我以为这里是「造神之地」时，一切却又奔着湮灭走去。",R.mipmap.img_srzy,fileContent));
            return list;
        } else if (position == 3) {
            filePath = map.get("我在精神病院学斩神");
            fileContent = readFileContent(filePath, "utf-8");
            list.add(new BookInfo(7,"我在精神病院学斩神","三九音域","你是否想过，在霓虹璀璨的都市之下，潜藏着来自古老神话的怪物？ 你是否想过，在那高悬于世人头顶的月亮之上，伫立着守望人间的神明？ 你是否想过，在人潮汹涌的现代城市之中，存在代替神明行走人间的超凡之人？ 人类统治的社会中，潜伏着无数诡异； 在那些无人问津的生命禁区，居住着古老的神明。 而属于大夏的神明，究竟去了何处？ 在这属于“人”的世界，“神秘”需要被肃清！",R.mipmap.img_wzjsbyxzh,fileContent));
            filePath = map.get("我不是戏神");
            fileContent = readFileContent(filePath, "utf-8");
            list.add(new BookInfo(9,"我不是戏神","三九音域","赤色流星划过天际后，人类文明陷入停滞。 从那天起，人们再也无法制造一枚火箭，一颗核弹，一架飞机，一台汽车……近代科学堆砌而成的文明金字塔轰然坍塌，而灾难，远不止此。 灰色的世界随着赤色流星降临，像是镜面后的鬼魅倒影，将文明世界一点点拖入无序的深渊。 在这个时代，人命渺如尘埃； 在这个时代，人类灿若星辰。 大厦将倾，有人见一戏子屹立文明废墟之上，红帔似血，时笑时哭， 时代的帘幕在他身后缓缓打开，他张开双臂，对着累累众生轻声低语—— “好戏......开场。”",R.mipmap.img_wbsxs,fileContent));
            return list;
        } else if (position == 4){
            filePath = map.get("异兽迷城");
            fileContent = readFileContent(filePath, "utf-8");
            list.add(new BookInfo(8,"异兽迷城","澎湃","高阳是个孤儿，六岁穿越到“平行世界”，从此生活在一个温馨的五口之家。 十八岁那年，高阳偶然发现世界真相：这里根本不是平行世界，而是一个神秘领域，身边的亲人朋友全是可怕的“兽”！发现真相的高阳差点被杀，关键时刻获得系统【幸运】——活得越久就越强！ 一场羔羊与狼的厮杀游戏由此展开……",R.mipmap.img_ysmc,fileContent));
            return list;
        } else {
            filePath = map.get("完美世界");
            fileContent = readFileContent(filePath, "utf-8");
            Alllist.add(new BookInfo(0, "完美世界","辰东",
                    "一粒尘可填海，一根草斩尽日月星辰，弹指间天翻地覆。\n" +
                            "群雄并起，万族林立，诸圣争霸，乱天动地。问苍茫大地，谁主沉浮？！\n" +
                            "一个少年从大荒中走出，一切从这里开始……",R.mipmap.img_wmsj,fileContent));
            filePath = map.get("遮天");
            fileContent = readFileContent(filePath, "utf-8");
            Alllist.add(new BookInfo(1, "遮天","辰东","冰冷与黑暗并存的宇宙深处，九具庞大的龙尸拉着一口青铜古棺，亘古长存。\n" +
                    "这是太空探测器在枯寂的宇宙中捕捉到的一幅极其震撼的画面。\n" +
                    "九龙拉棺，究竟是回到了上古，还是来到了星空的彼岸？\n" +
                    "一个浩大的仙侠世界，光怪陆离，神秘无尽。\n" +
                    "热血似火山沸腾，激情若瀚海汹涌，欲望如深渊无止境……\n" +
                    "登天路，踏歌行，弹指遮天。",R.mipmap.img_zt,fileContent));
            filePath = map.get("剑来");
            fileContent = readFileContent(filePath, "utf-8");
            Alllist.add(new BookInfo(2, "剑来","烽火戏诸侯","大千世界，无奇不有。我陈平安，唯有一剑，可搬山，断江，倒海，降妖，镇魔，敕神，摘星，摧城，开天！我叫陈平安，平平安安的平安，我是一名剑客。走北俱芦洲，问剑正阳山，赴大骊皇城，至蛮荒天下。斩大妖，了恩怨，会旧人，归故乡。刻字剑气长城，陈平安再开青萍剑宗！",R.mipmap.img_jl,fileContent));
            filePath = map.get("十日终焉");
            fileContent = readFileContent(filePath, "utf-8");
            Alllist.add(new BookInfo(3, "十日终焉","杀虫队队员","（不后宫，不套路，不无敌，不系统，不无脑，不爽文，介意者慎入。） 当我以为这只是寻常的一天时，却发现自己被捉到了终焉之地。 当我以为只需要不断的参加死亡游戏就可以逃脱时，却发现众人开始觉醒超自然之力。 当我以为这里是「造神之地」时，一切却又奔着湮灭走去。",R.mipmap.img_srzy,fileContent));
            filePath = map.get("庆余年");
            fileContent = readFileContent(filePath, "utf-8");
            Alllist.add(new BookInfo(4, "庆余年","猫腻","积善之家，必有余庆，留余庆，留余庆，忽遇恩人；幸娘亲，幸娘亲，积得阴功。劝人生，济困扶穷……而谁可知，人生于世，上承余庆，终究却是要自己做出道路抉择，正是所谓岔枝发：\n" +
                    "东风携云雨，幼藤吐新芽。\n" +
                    "急催如颦鼓，洗尽茸与华。\n" +
                    "且待朝阳至，绿遍庭中架。\n" +
                    "更盼黄叶时，采得数枚瓜。",R.mipmap.img_qyn,fileContent));
            filePath = map.get("明朝那些事儿");
            fileContent = readFileContent(filePath, "utf-8");
            Alllist.add(new BookInfo(5, "明朝那些事儿","当年明月","《明朝那些事儿》主要讲述的是从1344年到1644年这三百年间关于明朝的一些故事。以史料为基础，以年代和具体人物为主线，并加入了小说的笔法，语言幽默风趣。对明朝十七帝和其他王公权贵和小人物的命运进行全景展示，尤其对官场政治、战争、帝王心术着墨最多，并加入对当时政治经济制度、人伦道德的演义。它以一种网络语言向读者娓娓道出明朝三百多年的历史故事、人物。其中原本在历史中陌生、模糊的历史人物在书中一个个变得鲜活起来。《明朝那些事儿》为我们解读历史中的另一面，让历史变成一部活生生的生活故事。" ,R.mipmap.img_mcnxs,fileContent));
            filePath = map.get("蛊真人");
            fileContent = readFileContent(filePath, "utf-8");
            Alllist.add(new BookInfo(6, "蛊真人","真人",
                    "人是万物之灵，蛊是天地真精。\n" +
                            "三观不正，枭魔重生。\n" +
                            "昔日旧梦，同名新作。\n" +
                            "一个穿越者不断重生的故事。",R.mipmap.img_gzr, fileContent));
            filePath = map.get("我在精神病院学斩神");
            fileContent = readFileContent(filePath, "utf-8");
            Alllist.add(new BookInfo(7,"我在精神病院学斩神","三九音域","你是否想过，在霓虹璀璨的都市之下，潜藏着来自古老神话的怪物？ 你是否想过，在那高悬于世人头顶的月亮之上，伫立着守望人间的神明？ 你是否想过，在人潮汹涌的现代城市之中，存在代替神明行走人间的超凡之人？ 人类统治的社会中，潜伏着无数诡异； 在那些无人问津的生命禁区，居住着古老的神明。 而属于大夏的神明，究竟去了何处？ 在这属于“人”的世界，“神秘”需要被肃清！",R.mipmap.img_wzjsbyxzh,fileContent));
            filePath = map.get("异兽迷城");
            fileContent = readFileContent(filePath, "utf-8");
            Alllist.add(new BookInfo(8,"异兽迷城","百川归海","高阳是个孤儿，六岁穿越到“平行世界”，从此生活在一个温馨的五口之家。 十八岁那年，高阳偶然发现世界真相：这里根本不是平行世界，而是一个神秘领域，身边的亲人朋友全是可怕的“兽”！发现真相的高阳差点被杀，关键时刻获得系统【幸运】——活得越久就越强！ 一场羔羊与狼的厮杀游戏由此展开……",R.mipmap.img_ysmc,fileContent));
            filePath = map.get("我不是戏神");
            fileContent = readFileContent(filePath, "utf-8");
            Alllist.add(new BookInfo(9,"我不是戏神","三九音域","赤色流星划过天际后，人类文明陷入停滞。 从那天起，人们再也无法制造一枚火箭，一颗核弹，一架飞机，一台汽车……近代科学堆砌而成的文明金字塔轰然坍塌，而灾难，远不止此。 灰色的世界随着赤色流星降临，像是镜面后的鬼魅倒影，将文明世界一点点拖入无序的深渊。 在这个时代，人命渺如尘埃； 在这个时代，人类灿若星辰。 大厦将倾，有人见一戏子屹立文明废墟之上，红帔似血，时笑时哭， 时代的帘幕在他身后缓缓打开，他张开双臂，对着累累众生轻声低语—— “好戏......开场。”",R.mipmap.img_wbsxs,fileContent));
            return Alllist;
        }
    }
    public static String readFileContent(String filePath, String encoding) {
        StringBuilder contentBuilder = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), encoding))) {
            String currentLine;
            while ((currentLine = br.readLine()) != null) {
                contentBuilder.append(currentLine).append("\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return contentBuilder.toString();
    }
}
