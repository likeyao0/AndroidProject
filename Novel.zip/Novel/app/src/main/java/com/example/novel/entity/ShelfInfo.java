package com.example.novel.entity;

import java.io.Serializable;

public class ShelfInfo implements Serializable {
    private int shelf_user_id;
    private String username;
    private int book_id;
    private int book_img;
    private String book_title;
    private String book_author;
    private String book_details;
    private String book_content;
    private int book_count;
//    private int top;
//
//    public int isTop() {
//        return top;
//    }
//
//    public void setTop(int top) {
//        this.top = top;
//    }

    public int getBook_count() {
        return book_count;
    }

    public void setBook_count(int book_count) {
        this.book_count = book_count;
    }

    public int getShelf_user_id() {
        return shelf_user_id;
    }

    public void setShelf_user_id(int shelf_user_id) {
        this.shelf_user_id = shelf_user_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public int getBook_id() {
        return book_id;
    }

    public void setBook_id(int book_id) {
        this.book_id = book_id;
    }

    public int getBook_img() {
        return book_img;
    }

    public void setBook_img(int book_img) {
        this.book_img = book_img;
    }

    public String getBook_title() {
        return book_title;
    }

    public void setBook_title(String book_title) {
        this.book_title = book_title;
    }

    public String getBook_author() {
        return book_author;
    }

    public void setBook_author(String book_author) {
        this.book_author = book_author;
    }

    public String getBook_details() {
        return book_details;
    }

    public void setBook_details(String book_details) {
        this.book_details = book_details;
    }

    public String getBook_content() {
        return book_content;
    }

    public void setBook_content(String book_content) {
        this.book_content = book_content;
    }



    public ShelfInfo(String username, int shelf_user_id, int book_id, int book_img, String book_title, String book_author, String book_details, String book_content, int book_count) {
        this.username = username;
        this.shelf_user_id = shelf_user_id;
        this.book_id = book_id;
        this.book_img = book_img;
        this.book_title = book_title;
        this.book_author = book_author;
        this.book_details = book_details;
        this.book_content = book_content;
        this.book_count = book_count;
    }


//    public ShelfInfo( String username,int shelf_user_id, int book_id, int book_img, String book_title, String book_author, String book_details, String book_content, int book_count,int book_top) {
//        this.shelf_user_id = shelf_user_id;
//        this.username = username;
//        this.book_id = book_id;
//        this.book_img = book_img;
//        this.book_title = book_title;
//        this.book_author = book_author;
//        this.book_details = book_details;
//        this.book_content = book_content;
//        this.book_count = book_count;
//        this.top = top;
//    }
}
