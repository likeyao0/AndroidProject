package com.example.novel.model

import androidx.room.Entity
import androidx.room.PrimaryKey

//代表书籍的数据模型，可能包含书名、作者、ISBN等属性。
// 定义书评的数据模型
//@Entity(tableName = "review")
data class Review(
    val reviewerId: Int, // 书评作者的用户ID
    val reviewerUsername: String, // 书评作者的用户名
    val content: String, // 书评内容
    val date: String // 书评日期
)

// 定义Book数据模型，包括书评列表
@Entity(tableName = "books")
data class Book(
    @PrimaryKey(autoGenerate = true) val id: Int, // 书籍的唯一标识符
    val title: String, // 书名
    val author: String, // 作者
    val summary: String? = null, // 书籍简介，可能为空
    val coverImageUrl: String? = null, // 封面图片的URL，可能为空
    val reviews: List<Review> = emptyList() // 书评列表，默认为空列表
) {
    // 构造函数，用于创建Book对象
    // 这里可以根据需要添加更多的参数或者方法
}

//// 如果需要，可以添加一个伴生对象来提供一些静态方法或属性
//object Book {
//    const val DEFAULT_TITLE = "Unknown Book" // 默认书名，例如用于占位符
//
//    // 可以添加一个静态方法来创建一个默认书籍
//    fun defaultBook(): Book {
//        return Book(
//            id = 0,
//            title = DEFAULT_TITLE,
//            author = "Unknown Author",
//            summary = "No summary available.",
//            coverImageUrl = "https://example.com/default_cover.jpg",
//            reviews = emptyList()
//        )
//    }
//}