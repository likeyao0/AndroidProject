package com.example.novel.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "read_history",
    foreignKeys = [
        ForeignKey(entity = Book::class, // 引用Book实体
            parentColumns = ["id"], // Book实体的ID列
            childColumns = ["book_id"] // 本实体中引用Book ID的列
        ),
        ForeignKey(entity = User::class, // 引用User实体
            parentColumns = ["id"], // User实体的ID列
            childColumns = ["user_id"] // 本实体中引用User ID的列
        )
    ],
    indices = [Index("book_id"), Index("user_id")] // 为book_id和user_id列创建索引，优化查询
)
data class ReadHistory(
    val book_id: Int, // 书籍ID，对应Book实体的ID
    val user_id: Int, // 用户ID，表示哪个用户阅读了这本书
    val lastReadDate: String, // 最后阅读日期，可以存储为日期字符串
    val lastReadPage: Int // 最后阅读的页数
)