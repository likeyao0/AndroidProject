package com.example.novel.model

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index

@Entity(
    tableName = "shelf",
    foreignKeys = [
        ForeignKey(entity = Book::class, // 引用Book实体
            parentColumns = ["id"], // Book实体的ID列
            childColumns = ["book_id"] // 本实体中引用Book ID的列
        )
    ],
    indices = [Index("book_id")] // 为book_id列创建索引，优化查询
)
data class Shelf(
    val book_id: Int, // 书籍ID，对应Book实体的ID
    val user_id: Int // 用户ID，表示哪个用户收藏了这本书
)