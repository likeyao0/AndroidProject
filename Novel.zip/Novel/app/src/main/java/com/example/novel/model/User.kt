package com.example.novel.model

import androidx.room.Entity
import androidx.room.PrimaryKey

// 代表用户的数据模型，可能包含用户名、密码、邮箱等属性。
// 定义User数据模型
@Entity(tableName = "users")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int, // 用户的唯一标识符
    val username: String, // 用户名
    val password: String, // 密码
    val email: String // 邮箱地址
) {
    // 构造函数，用于创建User对象
    // 这里可以根据需要添加更多的参数或者方法
}

//// 如果需要，可以添加一个伴生对象来提供一些静态方法或属性
//object User {
//    const val DEFAULT_ID = 0 // 默认用户ID，例如用于未登录状态
//
//    // 可以添加一个静态方法来创建一个默认用户
//    fun defaultUser(): User {
//        return User(
//            id = DEFAULT_ID,
//            username = "Guest",
//            password = "",
//            email = ""
//        )
//    }
//}