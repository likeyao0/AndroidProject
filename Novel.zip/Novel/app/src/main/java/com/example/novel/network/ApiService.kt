package com.example.novel.network

//定义了与后端API交互的接口，使用Retrofit注解来声明网络请求。
import com.example.novel.model.Book
import retrofit2.Call
import retrofit2.http.GET
import retrofit2.http.Path

interface ApiService {
    // 获取所有书籍的列表
    @GET("books")
    fun getAllBooks(): Call<List<Book>>

    // 根据书籍ID获取特定书籍的详细信息
    @GET("books/{bookId}")
    fun getBookById(@Path("bookId") bookId: Int): Call<Book>
}