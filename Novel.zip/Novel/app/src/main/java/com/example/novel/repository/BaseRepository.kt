package com.example.novel.repository

//可能是一个基类，为其他仓库类提供共同的接口或实现。
import android.content.Context
import com.example.novel.database.AppDatabase
import com.example.novel.network.ApiService
import com.example.novel.network.NetworkClient

abstract class BaseRepository(private val context: Context) {
    protected val database: AppDatabase by lazy { AppDatabase.getDatabase(context) }
    protected val apiService: ApiService by lazy { NetworkClient.apiService }
}