package com.example.novel.repository

//封装了与书籍相关的数据操作，可能包括从数据库或网络获取书籍列表的逻辑。
import android.content.Context
import com.example.novel.database.AppDatabase
import com.example.novel.model.Book
import com.example.novel.network.ApiService
import kotlinx.coroutines.flow.Flow

class BookRepository(private val database: AppDatabase, private val apiService: ApiService, private val context: Context) {

    fun getAllBooks(): Flow<List<Book>> {
        return database.bookDao().getAllBooks()
    }

    suspend fun getBookById(bookId: Int): Book? {
        // 先从数据库查询，如果没有找到，再从网络获取
        val localBook = database.bookDao().getBookById(bookId)
        return if (localBook != null) {
            localBook
        } else {
            // 使用协程处理网络请求
            val response = apiService.getBookById(bookId).execute()
            if (response.isSuccessful) {
                response.body()?.let {
                    database.bookDao().insertBook(it) // 可以选择将网络获取的数据保存到数据库
                    it
                }
            } else {
                null
            }
        }
    }

    fun insertBook(newBook: Book) {
        val localBook = database.bookDao().getBookById(newBook.id)
        if (localBook == null){
            database.bookDao().insertBook(newBook)
        }
    }

    fun updateBook(updatedBook: Book) {
        database.bookDao().updateBook(updatedBook)
    }

    fun deleteBook(bookId: Int) {
        val localBook = database.bookDao().getBookById(bookId)
        if (localBook != null){
            database.bookDao().deleteBook(bookId)
        }
    }

    // 其他书籍相关的操作...
}