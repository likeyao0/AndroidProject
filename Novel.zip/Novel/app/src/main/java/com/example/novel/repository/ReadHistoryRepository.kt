package com.example.novel.repository

//封装了与阅读历史相关的数据操作。
import com.example.novel.database.AppDatabase
import com.example.novel.model.ReadHistory
import kotlinx.coroutines.flow.Flow


//class ReadHistoryRepository(private val database: AppDatabase) : BaseRepository() {
//
//    fun getReadHistory(): Flow<List<ReadHistory>> {
//        return database.readHistoryDao().getReadHistory()
//    }
//
//    // 其他阅读历史相关的操作...
//}