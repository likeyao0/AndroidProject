package com.example.novel.repository

//封装了与书架（用户收藏的书籍）相关的数据操作。
import com.example.novel.database.AppDatabase
import com.example.novel.model.Shelf

//class ShelfRepository(private val database: AppDatabase) : BaseRepository() {
//
//    fun getShelfBooks(): List<Shelf> {
//        return database.shelfDao().getShelfBooks()
//    }
//
//    // 其他书架相关的操作...
//}