package com.example.novel.service
//封装了与书籍相关的业务逻辑，可能包括获取书籍列表、搜索书籍等。

import com.example.novel.model.Book
import com.example.novel.repository.BookRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.map

class BookService(private val bookRepository: BookRepository) {

    // 获取所有书籍的列表
    fun getAllBooks(): Flow<List<Book>> {
        return bookRepository.getAllBooks()
            .catch { e ->
                // 处理可能发生的错误，例如通过返回一个空列表或者错误信息
                emptyList<Book>()
            }
    }

    // 根据书籍 ID 获取特定书籍的详细信息
    suspend fun getBookById(bookId: Int): Book? {
        return bookRepository.getBookById(bookId)
    }

    // 添加新书籍到数据库
    suspend fun addBook(newBook: Book) {
        bookRepository.insertBook(newBook)
    }

    // 更新书籍信息
    suspend fun updateBook(updatedBook: Book) {
        bookRepository.updateBook(updatedBook)
    }

    // 删除书籍
    suspend fun deleteBook(bookId: Int) {
        bookRepository.deleteBook(bookId)
    }

    // 其他与书籍相关的业务逻辑...
}