package com.example.novel.service
//封装了与阅读历史相关的业务逻辑。
class ReadHistoryRepository {
}