package com.example.novel.service
//封装了与书架相关的业务逻辑。
class ShelfService {
}