package com.example.novel.ui;

import static android.content.Context.MODE_PRIVATE;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.novel.BookDetailsActivity;
import com.example.novel.R;
import com.example.novel.adapter.BookCityAdapter;
import com.example.novel.adapter.RightListAdapter;
import com.example.novel.database.BookDbHelper;
import com.example.novel.database.ShelfDbHelper;
import com.example.novel.entity.BookInfo;
import com.example.novel.entity.DataService;
import com.example.novel.entity.ShelfInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class FragmentBookCity extends Fragment {

    private View rootView;
    private EditText search_book;
    private RecyclerView recyclerView_;
    private BookCityAdapter mBookCityAdapter;
    private LinearLayoutCompat ll_empty;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_book_city2, container, false);

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        ll_empty = rootView.findViewById(R.id.ll_empty);
        recyclerView_ = rootView.findViewById(R.id.recyclerView_);
        mBookCityAdapter = new BookCityAdapter();
        recyclerView_.setAdapter(mBookCityAdapter);
        search_book = rootView.findViewById(R.id.search_book);

        rootView.findViewById(R.id.btn_search).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String search_BookName = search_book.getText().toString();
//                List<BookInfo> bookInfos = BookDbHelper.getInstance(getActivity()).queryBookList(search_BookName);
//                List<BookInfo> bookInfos = new ArrayList<>();
//                List<BookInfo> BookInfos = DataService.getListData(5);
//
//                for (BookInfo item : BookInfos) {
//                    if (item.getBook_title().equals(search_BookName)){
//                        bookInfos.add(item);
//                    }
//                }

                List<BookInfo> bookList = BookDbHelper.getInstance(getActivity()).queryBookList(search_BookName);

                if (TextUtils.isEmpty(search_BookName)) {
                    Toast.makeText(getActivity(), "搜索内容为空~~~", Toast.LENGTH_SHORT).show();
                } else {
                    if (mBookCityAdapter != null) {
                        mBookCityAdapter.setBookInfoList(bookList);

                        if (bookList.size() == 0) {
                            Toast.makeText(getActivity(), "暂时没有该书籍~~~", Toast.LENGTH_SHORT).show();
                        }
                    }
                }
                if (bookList.size() == 0){
                    ll_empty.setVisibility(View.VISIBLE);
                    recyclerView_.setVisibility(View.GONE);
                } else {
                    ll_empty.setVisibility(View.GONE);
                    recyclerView_.setVisibility(View.VISIBLE);
                }
            }
        });


        mBookCityAdapter.setmOnItemClickListener(new RightListAdapter.onItemClickListener() {
            @Override
            public void onItemClick(BookInfo bookInfo, int position) {
                Intent intent = new Intent(getActivity(), BookDetailsActivity.class);
                intent.putExtra("bookInfo",bookInfo);
                startActivity(intent);
            }
        });
    }

}