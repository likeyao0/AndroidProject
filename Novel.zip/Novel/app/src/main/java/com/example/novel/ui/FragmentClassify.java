package com.example.novel.ui;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.novel.BookDetailsActivity;
import com.example.novel.R;
import com.example.novel.adapter.LeftListAdapter;
import com.example.novel.adapter.RightListAdapter;
import com.example.novel.entity.BookInfo;
import com.example.novel.entity.DataService;

import java.util.ArrayList;
import java.util.List;


public class FragmentClassify extends Fragment {

    private  View rootView;

    private RecyclerView leftRecyclerView;
    private RecyclerView rightRecyclerView;
    private RightListAdapter mRightListAdapter;

    private LeftListAdapter mLeftListAdapter;
    private List<String> leftDataList =new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_classify, container, false);

        leftRecyclerView = rootView.findViewById(R.id.leftRecyclerView);

        rightRecyclerView = rootView.findViewById(R.id.rightRecyclerView);

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState){
        super.onActivityCreated(savedInstanceState);

        leftDataList.add("古代");
        leftDataList.add("玄幻");
        leftDataList.add("悬疑");
        leftDataList.add("都市");
        leftDataList.add("穿越");

        mLeftListAdapter =new LeftListAdapter(leftDataList);
        leftRecyclerView.setAdapter(mLeftListAdapter);

        mRightListAdapter = new RightListAdapter();
        rightRecyclerView.setAdapter(mRightListAdapter);

        mRightListAdapter.setListData(DataService.getListData(0));

        mRightListAdapter.setmOnItemClickListener(new RightListAdapter.onItemClickListener() {
            @Override
            public void onItemClick(BookInfo bookInfo, int position) {
                Intent intent = new Intent(getActivity(), BookDetailsActivity.class);
                intent.putExtra("bookInfo",bookInfo);
                startActivity(intent);
            }
        });

        mLeftListAdapter.setMleftListOnClickItemListener(new LeftListAdapter.LeftListOnClickItemListener() {
            @Override
            public void onItemClick(int position) {
//                Toast.makeText(getActivity(), position+"--", Toast.LENGTH_SHORT).show();
                mLeftListAdapter.setCurrentIndex(position);

                mRightListAdapter.setListData(DataService.getListData(position));
            }
        });
    }
}