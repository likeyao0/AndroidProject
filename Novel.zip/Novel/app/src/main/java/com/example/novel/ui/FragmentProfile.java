package com.example.novel.ui;

import static android.content.Context.MODE_PRIVATE;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.example.novel.ContactCustomerService_Activity;
import com.example.novel.LoginActivity;
import com.example.novel.PrivacyPolicy_Activity;
import com.example.novel.R;
import com.example.novel.SystemNotifications_Activity;
import com.example.novel.UpdateNicknameActivity;
import com.example.novel.UpdatePwdActivity;
import com.example.novel.aboutAPP_Activity;
import com.example.novel.database.ShelfDbHelper;
import com.example.novel.database.UserDbHelper;
import com.example.novel.model.UserInfo;

public class FragmentProfile extends Fragment {

    private View rootView;
    private TextView tv_username;
    private TextView tv_nickname;
    private SharedPreferences mSharedPreferences;
    private SharedPreferences sharedPreferencesIsLogin;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_profile2, container, false);
        mSharedPreferences = getActivity().getSharedPreferences("user", MODE_PRIVATE);
        String username = mSharedPreferences.getString("username",null);
//        String password = "";

        tv_username = rootView.findViewById(R.id.tv_username);
        tv_nickname = rootView.findViewById(R.id.tv_nickname);

//------->

        UserInfo userInfo_ = UserInfo.getUserInfo(getActivity(),username);
        if (null != userInfo_){
            tv_username.setText(userInfo_.getUsername());
            tv_nickname.setText(userInfo_.getNickname());
        }

        rootView.findViewById(R.id.logout).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(getContext())
                        .setTitle("温馨提示")
                        .setMessage("确认要注销该账号吗？（该操作不可逆）")
                        .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                ShelfDbHelper.getInstance(getContext()).delete_User_All(username);
                                UserDbHelper.getInstance(getContext()).logoutUser(username);

                                sharedPreferencesIsLogin = getActivity().getSharedPreferences("app_preferences", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferencesIsLogin.edit();
                                editor.putBoolean("isLoggedIn", false); // 更新登录状态
                                editor.apply(); // 提交更改

                                getActivity().finish();
                                Intent intent = new Intent(getActivity(), LoginActivity.class);
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        })
                        .show();
            }
        });

        rootView.findViewById(R.id.exit).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new AlertDialog.Builder(getContext())
                        .setTitle("温馨提示")
                        .setMessage("确认要退出登录吗？")
                        .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {

                                sharedPreferencesIsLogin = getActivity().getSharedPreferences("app_preferences", Context.MODE_PRIVATE);
                                SharedPreferences.Editor editor = sharedPreferencesIsLogin.edit();
                                editor.putBoolean("isLoggedIn", false); // 更新登录状态
                                editor.apply(); // 提交更改

                                getActivity().finish();
                                Intent intent = new Intent(getActivity(), LoginActivity.class);
                                startActivity(intent);
                            }
                        })
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        })
                        .show();
            }
        });

        rootView.findViewById(R.id.tv_nickname).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), UpdateNicknameActivity.class);
                startActivityForResult(intent,1001);
            }

        });


        //update_pwd
        rootView.findViewById(R.id.updatePwd).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), UpdatePwdActivity.class);
                startActivityForResult(intent,1000);
            }
        });

        //Contact_customer_service
        rootView.findViewById(R.id.Contact_Customer_Service).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), ContactCustomerService_Activity.class);
                startActivity(intent);
            }
        });

        //System_Notifications
        rootView.findViewById(R.id.System_Notifications).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), SystemNotifications_Activity.class);
                startActivity(intent);
            }
        });

        //PrivacyPolicy
        rootView.findViewById(R.id.Privacy_Policy).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), PrivacyPolicy_Activity.class);
                startActivity(intent);
            }
        });

        //aboutAPP
        rootView.findViewById(R.id.about).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(), aboutAPP_Activity.class);
                startActivity(intent);
            }
        });

        return rootView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mSharedPreferences = getActivity().getSharedPreferences("user", MODE_PRIVATE);
        String username = mSharedPreferences.getString("username",null);
        if (requestCode == 1000) {
            getActivity().finish();
            Intent intent = new Intent(getActivity(), LoginActivity.class);
            startActivity(intent);
        }else if (resultCode == 1001) {
            UserInfo userInfo_ = UserInfo.getUserInfo(getActivity(),username);
            tv_nickname.setText(userInfo_.getNickname());
        }
    }
}