package com.example.novel.ui;

import static android.content.Context.MODE_PRIVATE;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.widget.LinearLayoutCompat;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.novel.AddBooksActivity;
import com.example.novel.ContentActivity;
import com.example.novel.R;
import com.example.novel.adapter.ShelfListAdapter;
import com.example.novel.database.ShelfDbHelper;
import com.example.novel.entity.ShelfInfo;

import java.util.List;


public class FragmentShelf extends Fragment {

    private  View rootView;
    private RecyclerView recyclerView;
    private ShelfListAdapter mShelfListAdapter;
    private SharedPreferences mSharedPreferences;
    private LinearLayoutCompat shelf_empty;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_shelf3, container, false);

        rootView.findViewById(R.id.btn_create_book).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity(),AddBooksActivity.class);
                startActivityForResult(intent,1003);
            }
        });

        return rootView;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);


        shelf_empty = rootView.findViewById(R.id.shelf_empty);
        recyclerView = rootView.findViewById(R.id.recyclerView);
        mShelfListAdapter = new ShelfListAdapter();
        recyclerView.setAdapter(mShelfListAdapter);

        mShelfListAdapter.setmOnItemClickListener(new ShelfListAdapter.onItemClickListener() {
            @Override
            public void onReadingOnClick(ShelfInfo shelfInfo, int position) {
                Intent intent = new Intent(getActivity(), ContentActivity.class);
                intent.putExtra("shelfInfo",shelfInfo);
                startActivity(intent);
                loadData();
            }

            @Override
            public void deOnClick(ShelfInfo shelfInfo, int position) {

                new AlertDialog.Builder(getActivity())
                        .setTitle("温馨提示")
                        .setMessage("确认是否要从书架删除书籍？")
                        .setPositiveButton("确认", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ShelfDbHelper.getInstance(getActivity()).delete(shelfInfo.getShelf_user_id()+"");
                                loadData();
                            }
                        })
                        .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                            }
                        })
                        .show();
            }
        });

        loadData();
    }

    public void loadData(){
        mSharedPreferences = getActivity().getSharedPreferences("user", MODE_PRIVATE);
        String username = mSharedPreferences.getString("username",null);
        List<ShelfInfo> shelfList = ShelfDbHelper.getInstance(getActivity()).queryShelfList(username);
        if (mShelfListAdapter != null) {
            mShelfListAdapter.setBookInfoList(shelfList);
        }

        if (mShelfListAdapter.getItemCount() != 0){
            shelf_empty.setVisibility(View.GONE);
        } else {
            shelf_empty.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1003) {
            loadData();
        }
    }
}