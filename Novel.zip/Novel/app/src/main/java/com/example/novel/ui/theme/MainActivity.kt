package com.example.novel.ui.theme;

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.novel.R
import com.google.android.material.bottomnavigation.BottomNavigationView
//import com.example.novel.ui.bookDetail.BookDetailFragment

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomAppBar)
//        bottomNavigationView.setOnNavigationItemSelectedListener { item ->
//            when (item.itemId) {
//                R.id.nav_home -> {
//                    // Handle home action
//                }
//                R.id.nav_shelf -> {
//                    // Handle shelf action
//                }
//                R.id.nav_book_city -> {
//                    // Handle book city action
//                }
//                R.id.nav_profile -> {
//                    // Handle profile action
//                }
//            }
//            true
//        }
    }
}